export class Customer {

    id: number=0;
    email: string='';
    firstname:string="";
    lastname:string="";
    fathername: string='';
    dob:Date|any;
    aadharnumber:string='';
    pannumber:string='';
    password: string='';
    mobilenumber:string='';
    country:string='';
    state:string="";
    city:string='';
    street:string='';
    pincode:number=0;
   
}